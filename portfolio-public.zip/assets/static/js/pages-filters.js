(() => {
  const items = [...document.querySelectorAll('[data-filter-item]')];
  const form = document.querySelector('[data-static-filter]');
  const gallery = document.querySelector('[data-static-gallery]');
  if (!form && !gallery) return;
  const french = document.documentElement.lang.startsWith('fr');
  const count = document.querySelector('[data-filter-count]');
  const empty = document.querySelector('[data-filter-empty]');
  const query = form?.querySelector('[name="q"]');
  const select = form?.querySelector('select');
  const category = form?.dataset.staticFilter || 'category';
  const params = new URLSearchParams(location.search);
  let selected = gallery ? params.get('category') || '' : '';
  const normalize = value => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase();
  const apply = () => {
    const terms = normalize(query?.value.trim() || '').split(/\s+/).filter(Boolean);
    const filter = select?.value || selected;
    let visible = 0;
    items.forEach(item => {
      const text = normalize(item.dataset.filterSearch || item.textContent);
      const values = JSON.parse(item.dataset.filterValues);
      const matches = terms.every(term => text.includes(term)) && (!filter || values.includes(filter));
      item.hidden = !matches;
      if (matches) visible++;
    });
    if (count) count.textContent = `${visible} ${french ? 'résultat(s)' : 'result(s)'}`;
    if (empty) empty.hidden = visible !== 0;
    const url = new URL(location.href);
    url.search = '';
    if (query?.value.trim()) url.searchParams.set('q', query.value.trim());
    if (filter) url.searchParams.set(category, filter);
    history.replaceState(null, '', url);
    gallery?.querySelectorAll('a').forEach(link => {
      const active = (new URL(link.href).searchParams.get('category') || '') === selected;
      if (active) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    });
  };
  if (form) {
    if (query) query.value = params.get('q') || '';
    if (select && [...select.options].some(option => option.value === params.get(category))) select.value = params.get(category);
    form.addEventListener('submit', event => { event.preventDefault(); apply(); });
    form.addEventListener('reset', () => { if (query) query.value = ''; if (select) select.value = ''; apply(); });
    form.hidden = false;
  }
  if (gallery) {
    gallery.querySelectorAll('a').forEach(link => link.addEventListener('click', event => {
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      event.preventDefault();
      selected = new URL(link.href).searchParams.get('category') || '';
      apply();
    }));
    gallery.hidden = false;
  }
  apply();
})();
