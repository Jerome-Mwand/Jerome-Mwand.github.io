document.querySelectorAll('[data-site-switcher]').forEach(switcher => {
  document.addEventListener('click', event => {
    if (!switcher.contains(event.target)) switcher.open = false;
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && switcher.open) {
      switcher.open = false;
      switcher.querySelector('summary').focus();
    }
  });
  switcher.addEventListener('focusout', () => {
    window.setTimeout(() => {
      if (!switcher.contains(document.activeElement)) switcher.open = false;
    }, 0);
  });
});
