(() => {
  let openPhoto = null;
  const descriptions = [...document.querySelectorAll("[data-gallery-text]")].map(text => {
    const button = text.parentElement.querySelector("[data-gallery-more]");
    const label = button.querySelector("[data-gallery-more-label]");
    const setExpanded = expanded => {
      text.toggleAttribute("data-collapsed", !expanded);
      if (!openPhoto) button.setAttribute("aria-expanded", String(expanded));
      label.textContent = expanded ? button.dataset.lessLabel : button.dataset.moreLabel;
    };
    button.addEventListener("click", () => {
      const photo = button.closest(".gallery-item")?.querySelector("[data-gallery-photo]");
      if (openPhoto && photo) openPhoto(photo, button);
      else setExpanded(button.getAttribute("aria-expanded") !== "true");
    });
    return { text, button, setExpanded };
  });
  const updateDescriptions = () => descriptions.forEach(({ text, button, setExpanded }) => {
    const expanded = button.getAttribute("aria-expanded") === "true";
    text.setAttribute("data-collapsed", "");
    const overflows = [...text.children].some(element => element.scrollHeight > element.clientHeight + 1);
    button.hidden = !overflows;
    setExpanded(overflows && expanded);
    if (!overflows) text.removeAttribute("data-collapsed");
  });
  let resizeFrame;
  window.addEventListener("resize", () => {
    cancelAnimationFrame(resizeFrame);
    resizeFrame = requestAnimationFrame(updateDescriptions);
  });
  updateDescriptions();
  document.fonts?.ready.then(updateDescriptions);

  const viewer = document.querySelector("[data-gallery-viewer]");
  const links = [...document.querySelectorAll("[data-gallery-photo]")];
  if (!viewer || !links.length || typeof viewer.showModal !== "function") return;
  const image = viewer.querySelector("[data-gallery-image]");
  const title = viewer.querySelector("h2");
  const caption = viewer.querySelector("[data-gallery-caption]");
  const error = viewer.querySelector("[data-gallery-error]");
  const position = viewer.querySelector("[data-gallery-position]");
  const previous = viewer.querySelector("[data-gallery-previous]");
  const next = viewer.querySelector("[data-gallery-next]");
  const close = viewer.querySelector("[data-gallery-close]");
  let index = 0, trigger, oldOverflow;
  let activeLinks = links;
  descriptions.forEach(({ button }) => {
    button.setAttribute("aria-haspopup", "dialog");
    button.removeAttribute("aria-expanded");
    button.setAttribute("aria-controls", "gallery-viewer");
  });
  const show = value => {
    index = (value + activeLinks.length) % activeLinks.length;
    const photo = activeLinks[index];
    error.hidden = true;
    image.alt = photo.dataset.alt;
    image.src = photo.href;
    title.textContent = photo.dataset.title;
    caption.textContent = photo.dataset.caption;
    caption.hidden = !caption.textContent;
    position.textContent = `${index + 1} / ${activeLinks.length}`;
    previous.disabled = next.disabled = activeLinks.length < 2;
  };
  image.addEventListener("error", () => { error.textContent = viewer.dataset.error; error.hidden = false; });
  openPhoto = (photo, source) => {
    activeLinks = links.filter(link => !link.closest('[data-filter-item]')?.hidden);
    const selected = activeLinks.indexOf(photo);
    if (selected < 0) return;
    trigger = source;
    show(selected);
    oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    viewer.showModal(); close.focus();
  };
  links.forEach(link => link.addEventListener("click", event => {
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    openPhoto(link, link);
  }));
  close.addEventListener("click", () => viewer.close());
  previous.addEventListener("click", () => show(index - 1));
  next.addEventListener("click", () => show(index + 1));
  viewer.addEventListener("keydown", event => {
    if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
      event.preventDefault(); show(index + (event.key === "ArrowLeft" ? -1 : 1));
    }
  });
  viewer.addEventListener("click", event => {
    const bounds = viewer.getBoundingClientRect();
    if (event.target === viewer && (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom)) viewer.close();
  });
  viewer.addEventListener("close", () => {
    document.body.style.overflow = oldOverflow;
    image.removeAttribute("src");
    trigger?.focus();
  });
})();
