(() => {
  const viewer = document.querySelector('#figure-viewer');
  if (!viewer || typeof viewer.showModal !== 'function') return;
  const image = viewer.querySelector('[data-figure-image]');
  const canvas = viewer.querySelector('.figure-canvas');
  const close = viewer.querySelector('[data-figure-close]');
  const zoomIn = viewer.querySelector('[data-figure-in]');
  const zoomOut = viewer.querySelector('[data-figure-out]');
  const scale = viewer.querySelector('[data-figure-scale]');
  const error = viewer.querySelector('[data-figure-error]');
  let zoom = 1, trigger, oldOverflow;
  const updateZoom = value => {
    zoom = Math.max(1, Math.min(3, value));
    image.style.width = `${zoom * 100}%`;
    image.classList.toggle('is-zoomed', zoom > 1);
    scale.textContent = `${zoom * 100}%`;
    zoomIn.disabled = zoom === 3;
    zoomOut.disabled = zoom === 1;
  };
  document.querySelectorAll('[data-figure-open]').forEach(link => {
    link.setAttribute('aria-haspopup', 'dialog');
    link.setAttribute('aria-controls', viewer.id);
    link.addEventListener('click', event => {
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      event.preventDefault();
      trigger = link;
      updateZoom(1);
      error.hidden = !(image.complete && image.naturalWidth === 0);
      oldOverflow = document.body.style.overflow;
      viewer.showModal();
      document.body.style.overflow = 'hidden';
      canvas.scrollTo(0, 0);
      close.focus();
    });
  });
  zoomIn.addEventListener('click', () => updateZoom(zoom + .5));
  zoomOut.addEventListener('click', () => updateZoom(zoom - .5));
  close.addEventListener('click', () => viewer.close());
  image.addEventListener('error', () => { error.hidden = false; });
  image.addEventListener('load', () => { error.hidden = true; });
  viewer.addEventListener('click', event => {
    const box = viewer.getBoundingClientRect();
    if (event.target === viewer && (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom)) viewer.close();
  });
  viewer.addEventListener('close', () => {
    document.body.style.overflow = oldOverflow;
    trigger?.focus();
  });
})();
