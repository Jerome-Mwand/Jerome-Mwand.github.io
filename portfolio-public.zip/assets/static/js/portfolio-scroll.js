(() => {
  const sections = [...document.querySelectorAll('[data-scroll-section]')];
  const links = [...document.querySelectorAll('[data-section-link]')];
  const header = document.querySelector('.site-header');
  const nav = document.querySelector('.site-nav');
  if (!sections.length || !nav || !header) return;
  let queued = false;
  let active = '';

  const update = () => {
    queued = false;
    const offset = header.getBoundingClientRect().height + 24;
    let current = sections[0].id;
    for (const section of sections) {
      if (section.getBoundingClientRect().top <= offset) current = section.id;
    }
    if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 4) {
      current = sections[sections.length - 1].id;
    }
    if (active === current) return;
    active = current;
    links.forEach(link => {
      const selected = link.dataset.sectionLink === current;
      link.classList.toggle('active', selected);
      if (selected) link.setAttribute('aria-current', 'location');
      else link.removeAttribute('aria-current');
    });
  };
  const schedule = () => {
    if (!queued) { queued = true; requestAnimationFrame(update); }
  };
  const resize = () => {
    document.documentElement.style.setProperty('--portfolio-header-height', `${header.getBoundingClientRect().height}px`);
    schedule();
  };
  window.addEventListener('scroll', schedule, { passive: true });
  window.addEventListener('resize', resize);
  window.addEventListener('hashchange', schedule);
  window.addEventListener('load', resize);
  if ('ResizeObserver' in window) new ResizeObserver(resize).observe(header);
  resize();
})();
