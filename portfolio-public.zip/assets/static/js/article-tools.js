(() => {
  const tools = document.querySelector('[data-copy-tools]');
  if (!tools) return;
  const status = tools.querySelector('[data-copy-status]');
  const fallback = tools.querySelector('[data-copy-fallback]');
  const field = fallback.querySelector('textarea');
  tools.querySelectorAll('[data-copy-value]').forEach(button => {
    button.hidden = false;
    button.addEventListener('click', async () => {
      status.textContent = '';
      fallback.hidden = true;
      try {
        await navigator.clipboard.writeText(button.dataset.copyValue);
        status.textContent = tools.dataset.success;
      } catch {
        field.value = button.dataset.copyValue;
        fallback.hidden = false;
        status.textContent = tools.dataset.fallback;
        field.focus();
        field.select();
      }
    });
  });
})();
