(() => {
  const french = document.documentElement.lang.startsWith('fr');
  document.querySelectorAll('[data-copy-citation]').forEach(button => {
    button.hidden = false;
    button.addEventListener('click', async () => {
      const item = button.closest('.research-item');
      const citation = item.querySelector('[data-citation-source]').textContent.trim();
      const status = item.querySelector('[data-citation-status]');
      button.disabled = true;
      try {
        await navigator.clipboard.writeText(citation);
        item.querySelector('.citation-fallback').hidden = true;
        status.textContent = french ? 'Référence copiée.' : 'Citation copied.';
      } catch {
        // Clipboard permissions and plain-HTTP mobile access may block copying.
        const fallback = item.querySelector('.citation-fallback');
        fallback.hidden = false;
        const field = fallback.querySelector('textarea');
        field.value = citation;
        field.focus();
        field.select();
        status.textContent = french ? 'Copiez la référence sélectionnée ci-dessous.' : 'Copy the selected citation below.';
      } finally {
        button.disabled = false;
      }
    });
  });
})();
