const root = document.documentElement;
let savedTheme;
try { savedTheme = localStorage.getItem("theme"); } catch { /* Storage can be unavailable in private browsers. */ }

if (savedTheme) {
  root.dataset.theme = savedTheme;
} else if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
  root.dataset.theme = "dark";
}

const themeToggle = document.querySelector("[data-theme-toggle]");
themeToggle?.setAttribute("aria-pressed", String(root.dataset.theme === "dark"));
themeToggle?.addEventListener("click", () => {
  const nextTheme = root.dataset.theme === "dark" ? "light" : "dark";
  root.dataset.theme = nextTheme;
  themeToggle.setAttribute("aria-pressed", String(nextTheme === "dark"));
  try { localStorage.setItem("theme", nextTheme); } catch { /* The selected theme still works for this visit. */ }
});

const mapEl = document.querySelector("#portfolio-map");
const layerSource = document.querySelector("#map-layer-source");

if (mapEl && layerSource) {
  const rawLayers = JSON.parse(layerSource.textContent);
  const layers = rawLayers.map((item) => item.fields || item);
  const language = document.documentElement.lang || "en";
  const bounds = {
    minLat: -4.55,
    maxLat: -4.22,
    minLng: 15.15,
    maxLng: 15.55,
  };

  mapEl.insertAdjacentHTML(
    "beforeend",
    '<div class="map-river"></div><div class="map-road one"></div><div class="map-road two"></div><div class="map-road three"></div>'
  );

  const toPoint = (layer) => {
    const lat = Number(layer.latitude);
    const lng = Number(layer.longitude);
    const x = ((lng - bounds.minLng) / (bounds.maxLng - bounds.minLng)) * 100;
    const y = (1 - (lat - bounds.minLat) / (bounds.maxLat - bounds.minLat)) * 100;
    return {
      x: Math.min(92, Math.max(8, x)),
      y: Math.min(88, Math.max(12, y)),
    };
  };

  const showPopup = (layer, point, trigger, index) => {
    if (trigger.getAttribute("aria-pressed") === "true" && mapEl.querySelector(".map-popup")) {
      mapEl.querySelector(".map-popup").remove();
      document.querySelectorAll(".map-marker, .map-layer").forEach(control => control.setAttribute("aria-pressed", "false"));
      trigger.focus();
      return;
    }
    mapEl.querySelector(".map-popup")?.remove();
    document.querySelectorAll(".map-marker, .map-layer").forEach(control => control.setAttribute("aria-pressed", "false"));
    document.querySelectorAll(`[data-layer-index="${index}"], [data-marker-index="${index}"]`).forEach(control => control.setAttribute("aria-pressed", "true"));
    const title = language === "fr" && layer.title_fr ? layer.title_fr : layer.title;
    const description = language === "fr" && layer.description_fr ? layer.description_fr : layer.description;
    const scoreLabel = language === "fr" ? "Score d'accessibilité" : "Accessibility score";
    const popup = document.createElement("div");
    popup.className = "map-popup";
    popup.tabIndex = -1;
    popup.setAttribute("role", "region");
    popup.setAttribute("aria-label", title);
    const close = document.createElement("button");
    close.type = "button";
    close.className = "map-popup-close";
    close.textContent = "\u00d7";
    close.setAttribute("aria-label", language === "fr" ? "Fermer les informations" : "Close information");
    const dismiss = () => {
      popup.remove();
      document.querySelectorAll(".map-marker, .map-layer").forEach(control => control.setAttribute("aria-pressed", "false"));
      trigger.focus();
    };
    close.addEventListener("click", dismiss);
    popup.addEventListener("keydown", event => {
      if (event.key === "Escape") { event.preventDefault(); dismiss(); }
    });
    const heading = document.createElement("h3");
    const copy = document.createElement("p");
    const score = document.createElement("strong");
    heading.textContent = title;
    copy.textContent = description;
    score.textContent = `${scoreLabel}: ${layer.accessibility_score}/100`;
    popup.append(close, heading, copy, score);
    mapEl.appendChild(popup);
    const left = Math.max(8, Math.min(mapEl.clientWidth - popup.offsetWidth - 8, mapEl.clientWidth * point.x / 100 + 10));
    const top = Math.max(8, Math.min(mapEl.clientHeight - popup.offsetHeight - 8, mapEl.clientHeight * point.y / 100 + 10));
    popup.style.left = `${left}px`;
    popup.style.top = `${top}px`;
    popup.focus();
  };

  layers.forEach((layer, index) => {
    const point = toPoint(layer);
    if (layer.layer_type === "area") {
      const area = document.createElement("div");
      area.className = "map-area";
      area.style.left = `${point.x}%`;
      area.style.top = `${point.y}%`;
      area.style.width = `${Math.max(70, Number(layer.radius) / 14)}px`;
      area.style.height = area.style.width;
      area.style.color = layer.color;
      mapEl.appendChild(area);
    }

    const marker = document.createElement("button");
    marker.type = "button";
    marker.className = "map-marker";
    marker.dataset.markerIndex = index;
    marker.style.left = `${point.x}%`;
    marker.style.top = `${point.y}%`;
    marker.style.background = layer.color;
    marker.textContent = layer.accessibility_score;
    marker.setAttribute("aria-label", language === "fr" && layer.title_fr ? layer.title_fr : layer.title);
    marker.setAttribute("aria-pressed", "false");
    marker.addEventListener("click", () => showPopup(layer, point, marker, index));
    mapEl.appendChild(marker);

    const layerButton = document.querySelector(`[data-layer-index="${index}"]`);
    layerButton?.setAttribute("aria-pressed", "false");
    layerButton?.addEventListener("click", () => showPopup(layer, point, layerButton, index));
  });
}
