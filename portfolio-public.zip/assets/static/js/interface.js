(() => {
  document.querySelectorAll("[data-print-page]").forEach(button => button.addEventListener("click", () => window.print()));
  const printDetails = [...document.querySelectorAll(".resume-more-training")];
  window.addEventListener("beforeprint", () => printDetails.forEach(item => { item.dataset.wasOpen = String(item.open); item.open = true; }));
  window.addEventListener("afterprint", () => printDetails.forEach(item => { item.open = item.dataset.wasOpen === "true"; delete item.dataset.wasOpen; }));
  const french = document.documentElement.lang.startsWith("fr");
  document.querySelector("[data-contact-errors]")?.focus();
  const toggle = document.querySelector("[data-nav-toggle]");
  const nav = document.querySelector("[data-site-nav]");
  if (nav && toggle) {
    const compact = matchMedia(`(max-width: ${nav.dataset.navBreakpoint || 900}px)`);
    const backdrop = document.createElement("div");
    backdrop.className = "navigation-backdrop";
    backdrop.hidden = true;
    nav.before(backdrop);
    const close = document.createElement("button");
    close.type = "button";
    close.className = "navigation-close";
    close.textContent = "\u00d7";
    close.setAttribute("aria-label", french ? "Fermer le menu" : "Close menu");
    nav.prepend(close);
    let previousOverflow = null;
    const setOpen = (open, restoreFocus = false) => {
      nav.classList.toggle("open", open);
      toggle.setAttribute("aria-expanded", String(open));
      nav.inert = compact.matches && !open;
      backdrop.hidden = !open || !compact.matches;
      if (open && compact.matches) {
        if (previousOverflow === null) previousOverflow = document.body.style.overflow;
        document.body.style.overflow = "hidden";
      } else if (previousOverflow !== null) {
        document.body.style.overflow = previousOverflow;
        previousOverflow = null;
      }
      if (open) close.focus({ preventScroll: true });
      if (restoreFocus) toggle.focus();
    };
    toggle.addEventListener("click", () => setOpen(!nav.classList.contains("open")));
    close.addEventListener("click", () => setOpen(false, true));
    backdrop.addEventListener("click", () => setOpen(false, true));
    nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
      setOpen(false);
      const destination = new URL(link.href, location.href);
      if (destination.origin !== location.origin || destination.pathname !== location.pathname || !destination.hash) return;
      let target;
      try { target = document.getElementById(decodeURIComponent(destination.hash.slice(1))); } catch { return; }
      if (!target) return;
      const heading = target.querySelector("h1, h2") || target;
      heading.tabIndex = -1;
      requestAnimationFrame(() => heading.focus({ preventScroll: true }));
    }));
    document.addEventListener("keydown", event => {
      if (!compact.matches || !nav.classList.contains("open")) return;
      if (event.key === "Escape") setOpen(false, true);
      if (event.key === "Tab") {
        const items = [...nav.querySelectorAll("a, button")].filter(el => el.getClientRects().length);
        const first = items[0], last = items[items.length - 1];
        if (event.shiftKey && (document.activeElement === first || document.activeElement === toggle)) {
          event.preventDefault(); last?.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault(); first?.focus();
        }
      }
    });
    compact.addEventListener("change", () => setOpen(false));
    setOpen(false);
    const current = nav.querySelector("a.active:not([hreflang])");
    current?.setAttribute("aria-current", "page");
  }

  document.querySelectorAll("[data-public-slider], [data-auth-slider]").forEach(slider => {
    const auth = slider.hasAttribute("data-auth-slider");
    const scope = auth ? document.body : slider;
    const slides = [...slider.querySelectorAll("[data-public-slide], [data-auth-slide]")];
    const controls = [...scope.querySelectorAll("[data-public-slide-button], [data-auth-slide-button]")];
    const pause = scope.querySelector("[data-slider-toggle]");
    const reduced = matchMedia("(prefers-reduced-motion: reduce)");
    const mobile = matchMedia("(max-width: 820px)");
    const manual = slider.hasAttribute("data-slider-manual");
    let active = 0, paused = manual || reduced.matches, hovered = false, focused = false, timer;
    const show = index => {
      active = (index + slides.length) % slides.length;
      slides.forEach((slide, i) => slide.classList.toggle("active", i === active));
      controls.forEach((control, i) => {
        control.classList.toggle("active", i === active);
        control.setAttribute("aria-current", String(i === active));
      });
      const next = slides[(active + 1) % slides.length]?.querySelector("img");
      if (next) next.loading = "eager";
    };
    const rotate = () => {
      clearInterval(timer);
      if (!paused && !hovered && !focused && !document.hidden && !reduced.matches && !(auth && mobile.matches) && slides.length > 1) {
        timer = setInterval(() => show(active + 1), 7000);
      }
      if (pause) {
        const stopped = paused || reduced.matches;
        pause.textContent = stopped ? pause.dataset.playLabel : pause.dataset.pauseLabel;
        pause.setAttribute("aria-label", pause.textContent);
        pause.title = pause.textContent;
        pause.setAttribute("aria-pressed", String(stopped));
      }
    };
    pause?.addEventListener("click", () => { paused = !paused; rotate(); });
    controls.forEach((control, i) => control.addEventListener("click", () => { show(i); paused = true; rotate(); }));
    scope.addEventListener("focusin", () => { focused = true; rotate(); });
    scope.addEventListener("focusout", event => { focused = scope.contains(event.relatedTarget); rotate(); });
    slider.addEventListener("mouseenter", () => { hovered = true; rotate(); });
    slider.addEventListener("mouseleave", () => { hovered = false; rotate(); });
    document.addEventListener("visibilitychange", rotate);
    reduced.addEventListener("change", () => { paused = manual || reduced.matches; rotate(); });
    mobile.addEventListener("change", () => { if (auth && mobile.matches) show(0); rotate(); });
    show(0); rotate();
  });

  // Associate server-rendered errors with their controls and bring them into view.
  document.querySelectorAll("form").forEach(form => {
    const invalid = [];
    form.querySelectorAll("label").forEach(label => {
      const error = label.querySelector(".error, em, .errorlist");
      const field = label.querySelector("input:not([type=hidden]), select, textarea");
      if (!error || !field) return;
      error.id ||= `${field.id || field.name}-error`;
      field.setAttribute("aria-invalid", "true");
      field.setAttribute("aria-describedby", `${field.getAttribute("aria-describedby") || ""} ${error.id}`.trim());
      invalid.push(field);
    });
    const existing = form.querySelector(".form-errors, .portal-form-errors") || form.previousElementSibling?.matches(".portal-form-errors") && form.previousElementSibling;
    if (invalid.length || existing) {
      const summary = existing || document.createElement("p");
      if (!existing) {
        summary.className = document.body.classList.contains("portal-body") || document.body.classList.contains("portal-auth-body") ? "portal-form-errors" : "form-errors";
        summary.textContent = french ? "Veuillez corriger les champs indiqués." : "Please check the highlighted fields.";
        form.prepend(summary);
      }
      summary.setAttribute("role", "alert"); summary.tabIndex = -1;
      summary.focus();
    }
  });
  document.querySelectorAll("form.contact-form").forEach(form => form.addEventListener("submit", () => {
    const button = form.querySelector('button[type="submit"]');
    if (button) { button.dataset.originalLabel = button.textContent; button.disabled = true; button.textContent = french ? "Envoi en cours..." : "Sending..."; }
  }));
  addEventListener("pageshow", () => {
    document.querySelectorAll("[data-original-label]").forEach(button => {
      button.textContent = button.dataset.originalLabel;
      button.disabled = false;
      button.removeAttribute("aria-disabled");
    });
  });
})();
